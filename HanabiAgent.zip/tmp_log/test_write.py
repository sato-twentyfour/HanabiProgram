
log_path = r'C:\Users\AtsushiKawagoe\Documents\about_lab\hanabi_web\dev\tmp_log\log_id_test.txt'
try:
    with open(log_path,'a') as log_file:
        log_file.write("unchi sono1")
        log_file.close()
except:
    print("error 1")


string = "test string"

try:
    with open(log_path,'a') as log_file:
        log_file.write(string)
        log_file.close()
except:
    print("error 2")
